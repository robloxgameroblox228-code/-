package com.vrvision.app

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFF8B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 11, 16)
        window.navigationBarColor = android.graphics.Color.rgb(9, 11, 16)
        setContent { VRVisionApp() }
    }
}

@Composable
private fun VRVisionApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("Видео не выбрано") }
    var videoUrl by remember { mutableStateOf("") }
    var gap by remember { mutableFloatStateOf(8f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var roundness by remember { mutableFloatStateOf(1f) }
    var lens by remember { mutableStateOf("Круглые") }
    var sound by remember { mutableStateOf(true) }
    var sbs by remember { mutableStateOf(true) }
    var settingsOpen by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var isVr by remember { mutableStateOf(false) }

    val playerLeft = remember { ExoPlayer.Builder(context).build() }
    val playerRight = remember { ExoPlayer.Builder(context).build() }

    DisposableEffect(Unit) {
        onDispose { playerLeft.release(); playerRight.release() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Выбранное видео"
            val item = MediaItem.fromUri(uri)
            playerLeft.setMediaItem(item)
            playerRight.setMediaItem(item)
            playerLeft.prepare(); playerRight.prepare()
            playerLeft.volume = if (sound) 1f else 0f
            playerRight.volume = 0f
            playing = false
        }
    }

    LaunchedEffect(playerLeft, selectedUri) {
        while (true) {
            if (selectedUri != null) {
                duration = playerLeft.duration.coerceAtLeast(0L)
                position = playerLeft.currentPosition.coerceAtLeast(0L)
                playing = playerLeft.isPlaying
                if (playerRight.currentPosition - playerLeft.currentPosition !in -250L..250L && playerLeft.isPlaying) {
                    playerRight.seekTo(playerLeft.currentPosition)
                }
            }
            delay(250)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VR VISION", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("ТВОЁ ОКНО В ВИРТУАЛЬНУЮ РЕАЛЬНОСТЬ", color = Color.Gray, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                IconButton(onClick = { settingsOpen = !settingsOpen }) {
                    Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (isVr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("VR-ПРОСМОТР", color = Accent, fontWeight = FontWeight.Bold)
                    TextButton(onClick = {
                        isVr = false
                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        activity.window.decorView.systemUiVisibility = 0
                    }) { Text("ВЫЙТИ") }
                }
                Spacer(Modifier.height(8.dp))
                DualPreview(selectedUri, playerLeft, playerRight, gap, zoom, lens, roundness, sbs, Modifier.weight(1f))
            } else {
                Text("ПРОСМОТР", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                DualPreview(selectedUri, playerLeft, playerRight, gap, zoom, lens, roundness, sbs, Modifier.fillMaxWidth().weight(1f).heightIn(min = 180.dp, max = 360.dp))
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FolderOpen, null, tint = Accent)
                    Spacer(Modifier.width(8.dp))
                    Text(fileName, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f), fontSize = 12.sp)
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                        Text("Выбрать видео", color = Color.White)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = videoUrl,
                        onValueChange = { videoUrl = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Прямая ссылка на видео") },
                        placeholder = { Text("https://.../video.mp4") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val raw = videoUrl.trim()
                        if (raw.startsWith("https://") || raw.startsWith("http://")) {
                            val uri = Uri.parse(raw)
                            selectedUri = uri
                            fileName = uri.lastPathSegment ?: "Интернет-видео"
                            val item = MediaItem.fromUri(uri)
                            playerLeft.setMediaItem(item); playerRight.setMediaItem(item)
                            playerLeft.prepare(); playerRight.prepare()
                            playerLeft.volume = if (sound) 1f else 0f; playerRight.volume = 0f
                        }
                    }, enabled = videoUrl.trim().startsWith("https://") || videoUrl.trim().startsWith("http://")) { Text("Открыть") }
                }
                if (selectedUri != null) {
                    Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                        onValueChange = { playerLeft.seekTo(it.toLong()); playerRight.seekTo(it.toLong()) },
                        valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(timeText(position), color = Color.Gray, fontSize = 10.sp)
                        Text(timeText(duration), color = Color.Gray, fontSize = 10.sp)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { playerLeft.seekTo(0); playerRight.seekTo(0) }) { Icon(Icons.Default.Stop, null, tint = Color.White) }
                    FilledIconButton(onClick = {
                        if (playerLeft.isPlaying) { playerLeft.pause(); playerRight.pause() }
                        else { playerRight.seekTo(playerLeft.currentPosition); playerLeft.play(); playerRight.play() }
                    }, enabled = selectedUri != null, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Звук", color = Color.White, fontSize = 12.sp)
                        Switch(checked = sound, onCheckedChange = {
                            sound = it; playerLeft.volume = if (it) 1f else 0f; playerRight.volume = 0f
                        })
                    }
                }
                if (settingsOpen) {
                    SettingsPanel(gap, { gap = it }, zoom, { zoom = it }, lens, { lens = it }, roundness, { roundness = it }, sbs, { sbs = it })
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    isVr = true
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    activity.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
                }, enabled = selectedUri != null, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(14.dp)) {
                    Text("ЗАПУСТИТЬ VR-ПРОСМОТР", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
private fun DualPreview(uri: Uri?, left: ExoPlayer, right: ExoPlayer, gap: Float, zoom: Float, lens: String, roundness: Float, sbs: Boolean, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(18.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        val shape = when (lens) {
            "Овальные" -> RoundedCornerShape(50)
            "Скруглённые" -> RoundedCornerShape((roundness * 30).dp)
            "Прямоугольные" -> RoundedCornerShape(4.dp)
            else -> CircleShape
        }
        if (uri == null) {
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape).background(Color(0xFF171B25)), contentAlignment = Alignment.Center) { Text("L", color = Color.Gray, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(gap.dp))
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape).background(Color(0xFF171B25)), contentAlignment = Alignment.Center) { Text("R", color = Color.Gray, fontWeight = FontWeight.Bold) }
        } else {
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape)) { PlayerSurface(left, zoom, sbs, true) }
            Spacer(Modifier.width(gap.dp))
            Box(Modifier.weight(1f).fillMaxHeight().clip(shape)) { PlayerSurface(right, zoom, sbs, false) }
        }
    }
}

@Composable
private fun PlayerSurface(player: ExoPlayer, zoom: Float, sbs: Boolean, leftEye: Boolean) {
    AndroidView(factory = { ctx ->
        PlayerView(ctx).apply {
            this.player = player
            useController = false
            resizeMode = if (zoom > 1.05f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(android.graphics.Color.BLACK)
        }
    }, update = { view ->
        view.player = player
        view.resizeMode = if (zoom > 1.05f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }, modifier = Modifier.fillMaxSize().graphicsLayer {
        if (sbs) {
            scaleX = 2f
            translationX = if (leftEye) size.width / 2f else -size.width / 2f
        }
    })
}

@Composable
private fun SettingsPanel(gap: Float, onGap: (Float) -> Unit, zoom: Float, onZoom: (Float) -> Unit, lens: String, onLens: (String) -> Unit, roundness: Float, onRoundness: (Float) -> Unit, sbs: Boolean, onSbs: (Boolean) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text("НАСТРОЙКИ ОЧКОВ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        SettingSlider("Расстояние между глазами", gap, 0f..36f, onGap, "${gap.toInt()} px")
        SettingSlider("Масштаб", zoom, 1f..2f, onZoom, "${"%.1f".format(zoom)}×")
        Text("Форма линз", color = Color.LightGray, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Круглые", "Овальные", "Скруглённые", "Прямоугольные").forEach { item ->
                FilterChip(selected = lens == item, onClick = { onLens(item) }, label = { Text(item, fontSize = 9.sp) })
            }
        }
        if (lens == "Скруглённые") SettingSlider("Скругление", roundness, 0.2f..1f, onRoundness, "${(roundness * 100).toInt()}%")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Стерео Side-by-Side", color = Color.White, fontSize = 12.sp)
            Switch(checked = sbs, onCheckedChange = onSbs)
        }
        Text("Примечание: в текущей версии оба глаза показывают выбранный файл целиком. Для настоящего 3D нужен исходный SBS/VR-видеофайл.", color = Color.Gray, fontSize = 9.sp)
    }
}

@Composable
private fun SettingSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit, trailing: String) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.LightGray, fontSize = 11.sp)
            Text(trailing, color = Accent, fontSize = 11.sp)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
    }
}

private fun timeText(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
